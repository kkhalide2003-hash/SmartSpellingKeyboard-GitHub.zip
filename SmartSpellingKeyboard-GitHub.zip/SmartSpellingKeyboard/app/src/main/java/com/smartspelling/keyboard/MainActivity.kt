package com.smartspelling.keyboard

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(36, 36, 36, 36)
            setBackgroundColor(0xFF10131A.toInt())
        }

        val title = TextView(this).apply {
            text = "مساعد الإملاء"
            textSize = 30f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }

        val info = TextView(this).apply {
            text = "\nكيبورد عربي وإنجليزي مصمم للتعلّم والإملاء.\n" +
                    "ينطق الحرف بصوت قريب من موقعه داخل الكلمة، " +
                    "وعند الضغط على المسافة ينطق الكلمة كاملة.\n"
            textSize = 17f
            setTextColor(0xFFD9DEE9.toInt())
            gravity = Gravity.CENTER
        }

        val enable = Button(this).apply {
            text = "تفعيل الكيبورد"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
            }
        }

        val choose = Button(this).apply {
            text = "اختيار الكيبورد"
            setOnClickListener {
                val imm = getSystemService(INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
                imm.showInputMethodPicker()
            }
        }

        root.addView(title)
        root.addView(info)
        root.addView(enable)
        root.addView(choose)
        setContentView(root)
    }
}
