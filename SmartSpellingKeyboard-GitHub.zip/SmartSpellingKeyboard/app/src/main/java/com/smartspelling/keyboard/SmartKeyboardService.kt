package com.smartspelling.keyboard

import android.inputmethodservice.InputMethodService
import android.speech.tts.TextToSpeech
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.GridLayout
import android.widget.LinearLayout
import java.util.Locale

class SmartKeyboardService : InputMethodService(), TextToSpeech.OnInitListener {

    private lateinit var tts: TextToSpeech
    private var arabic = true
    private var dark = true
    private var speakLetters = true
    private var lastWord = ""

    private val arRows = listOf(
        "ض ص ث ق ف غ ع ه خ ح ج",
        "ش س ي ب ل ا ت ن م ك ة",
        "ئ ء ؤ ر لا ى د ذ ط ظ ز و"
    )

    private val enRows = listOf(
        "Q W E R T Y U I O P",
        "A S D F G H J K L",
        "Z X C V B N M"
    )

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = if (arabic) Locale("ar") else Locale.US
            tts.setSpeechRate(0.82f)
        }
    }

    override fun onStartInput(info: EditorInfo?, restarting: Boolean) {
        super.onStartInput(info, restarting)
        lastWord = ""
    }

    override fun onCreateInputView(): View {
        return buildKeyboard()
    }

    private fun buildKeyboard(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(8, 8, 8, 8)
            setBackgroundColor(if (dark) 0xFF151922.toInt() else 0xFFF2F4F8.toInt())
        }

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        fun topButton(text: String, action: () -> Unit): Button =
            Button(this).apply {
                this.text = text
                textSize = 13f
                setOnClickListener { action() }
                layoutParams = LinearLayout.LayoutParams(0, 54, 1f).apply { setMargins(3,3,3,3) }
            }

        top.addView(topButton(if (arabic) "EN" else "ع", { arabic = !arabic; rebuild() }))
        top.addView(topButton(if (dark) "☀" else "☾", { dark = !dark; rebuild() }))
        top.addView(topButton("🔊", { speakWordUnderCursor() }))
        top.addView(topButton("⌫", { deleteOne() }))
        root.addView(top)

        val grid = GridLayout(this).apply {
            columnCount = 10
            rowCount = 3
        }

        val rows = if (arabic) arRows else enRows
        rows.forEach { row ->
            row.trim().split(Regex("\\s+")).forEach { ch ->
                val b = Button(this).apply {
                    text = ch
                    textSize = if (arabic) 21f else 19f
                    setOnClickListener { typeCharacter(ch) }
                    setBackgroundColor(if (dark) 0xFF252B38.toInt() else 0xFFFFFFFF.toInt())
                }
                val p = GridLayout.LayoutParams().apply {
                    width = 0
                    height = 58
                    columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                    setMargins(2,2,2,2)
                }
                grid.addView(b, p)
            }
        }
        root.addView(grid)

        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        fun actionButton(text: String, action: () -> Unit): Button =
            Button(this).apply {
                this.text = text
                textSize = 14f
                setOnClickListener { action() }
                layoutParams = LinearLayout.LayoutParams(0, 58, 1f).apply { setMargins(3,3,3,3) }
            }

        actions.addView(actionButton("،", { typeCharacter("،") }))
        actions.addView(actionButton("مسافة", { spaceAndSpeak() }))
        actions.addView(actionButton("⏎", { sendKey(KeyEvent.KEYCODE_ENTER) }))
        actions.addView(actionButton("نسخ", { copyText() }))
        root.addView(actions)

        val help = Button(this).apply {
            text = "💡 اقتراحات الإملاء"
            setOnClickListener { speak("اكتب الكلمة بهدوء، استمع لصوت الحرف، ثم أكمل الكلمة. عند المسافة سأقرأ الكلمة كاملة.") }
        }
        root.addView(help)

        return root
    }

    private fun rebuild() {
        setInputView(buildKeyboard())
    }

    private fun typeCharacter(ch: String) {
        currentInputConnection?.commitText(ch, 1)
        if (speakLetters) {
            val contextText = contextualSpeech(ch)
            speak(contextText)
        }
    }

    /*
     * الفكرة التعليمية الأساسية:
     * لا نرسل للحروف العربية صوتاً منفرداً فقط؛ بل نبني مقطعاً قصيراً
     * من الحرف مع حركة مناسبة حتى يكون الصوت أقرب لصوت الحرف داخل كلمة.
     * مثال: ب -> "بَ"، م -> "مَ"، ش -> "شَ".
     * ويمكن لاحقاً استبدال هذه الطبقة بملفات phoneme/syllable مسجلة
     * للحصول على نطق أدق حسب موقع الحرف (أول/وسط/آخر).
     */
    private fun contextualSpeech(ch: String): String {
        if (!arabic) {
            val c = ch.uppercase(Locale.US)
            val vowel = when (c) {
                "B","C","D","F","G","H","J","K","P","Q","T","V","W","X","Y","Z" -> "uh"
                else -> c
            }
            return vowel
        }
        return when (ch) {
            "ا" -> "أَ"
            "ب" -> "بَ"
            "ت" -> "تَ"
            "ث" -> "ثَ"
            "ج" -> "جَ"
            "ح" -> "حَ"
            "خ" -> "خَ"
            "د" -> "دَ"
            "ذ" -> "ذَ"
            "ر" -> "رَ"
            "ز" -> "زَ"
            "س" -> "سَ"
            "ش" -> "شَ"
            "ص" -> "صَ"
            "ض" -> "ضَ"
            "ط" -> "طَ"
            "ظ" -> "ظَ"
            "ع" -> "عَ"
            "غ" -> "غَ"
            "ف" -> "فَ"
            "ق" -> "قَ"
            "ك" -> "كَ"
            "ل" -> "لَ"
            "م" -> "مَ"
            "ن" -> "نَ"
            "ه" -> "هَ"
            "و" -> "وَ"
            "ي" -> "يَ"
            "ء" -> "هَمْزَة"
            "ة" -> "تَاء مَرْبُوطَة"
            "ى" -> "أَلِف مَقْصُورَة"
            "لا" -> "لَا"
            else -> ch
        }
    }

    private fun spaceAndSpeak() {
        val ic = currentInputConnection ?: return
        ic.commitText(" ", 1)
        speakWordUnderCursor()
    }

    private fun speakWordUnderCursor() {
        val ic = currentInputConnection ?: return
        val before = ic.getTextBeforeCursor(80, 0) ?: ""
        val word = before.trim().split(Regex("\\s+")).lastOrNull() ?: ""
        if (word.isNotEmpty()) {
            lastWord = word
            speak(word)
        }
    }

    private fun speak(text: String) {
        if (!::tts.isInitialized) return
        tts.language = if (arabic) Locale("ar") else Locale.US
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "smart_${System.nanoTime()}")
    }

    private fun deleteOne() {
        currentInputConnection?.deleteSurroundingText(1, 0)
    }

    private fun copyText() {
        val ic = currentInputConnection ?: return
        val text = ic.getTextBeforeCursor(2000, 0)?.toString() ?: return
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
        clipboard.setPrimaryClip(android.content.ClipData.newPlainText("مساعد الإملاء", text))
        speak(if (arabic) "تم النسخ" else "Copied")
    }

    private fun sendKey(code: Int) {
        currentInputConnection?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        currentInputConnection?.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    override fun onDestroy() {
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        super.onDestroy()
    }
}
